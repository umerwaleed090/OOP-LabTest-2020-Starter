/*
umer waleed
compiler = virtual code
date = 22/04/2020
we have to creat a gantt chart using the processing
*/

package ie.tudublin;

public class Main
{

    public void gant()
	{
		String[] a = {"MAIN"};
        processing.core.PApplet.runSketch( a, new Gantt());
    }
    
    public static void main(String[] arg)
    {
        Main main = new Main();
		main.gant();        
    }
}