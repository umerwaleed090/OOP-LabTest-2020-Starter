package ie.tudublin;

import processing.core.PApplet;
import processing.data.*;
import java.util.*;

public class Gantt extends PApplet {

    private float starting_space = 85f;
    private float gap = width / 5f;
    private int Rect_Size = 55;

    private float area_of_box = 15f;
    private int selectRight = 1;
    private int selectLeft = -1;

    private ArrayList<Task> tasks = new ArrayList<>();

    public void settings() {
        size(900, 750);
    }

    public void loadTasks() {
        Table table = loadTable("tasks.csv", "header");

        table.rows().forEach(tableRow -> tasks.add(new Task(tableRow)));
    }

    public void printTasks() {
        tasks.forEach(System.out::println);
    }

    public void displayTasks() {
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);

            float y_axis = map(i, 0, tasks.size(), gap * 5,height - gap);

            fill(255);
            text(task.getTask(), gap, y_axis);

            noStroke();
            fill(map(i, 0, tasks.size(), 0, 255), 255, 255);

            float begin = map(task.getStart(), 1, 30, starting_space, width - gap);
            float finish = map(task.getEnd(), 1, 30, starting_space, width - gap);
            rect(begin, y_axis - (Rect_Size / 2), finish - begin, Rect_Size, 5, 5, 5, 5);
        }

        stroke(255);

        for (int j = 1; j <= 30; j++) {
            float x_axis = map(j, 1, 30, starting_space, width - gap);

            line(x_axis, gap + 30, x_axis, height - gap);
            fill(255);
            text(j, x_axis - 2, gap / 3);
        }
    }

    public void mousePressed() {
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);

            //position of upper part of rectangle
            float up_start = map(task.getStart(), 1, 30, starting_space, width - gap);
            float up_finish = map(task.getEnd(), 1, 30, starting_space, width - gap);

            //position of down part of rectangle
            float down_begin = map(i, 0, tasks.size(), gap * 5, height - gap) - (Rect_Size / 2);
            float down_finish = down_begin + up_finish;

            //change shape based on cursor hovering
            if (mouseY >= down_begin && mouseY <= down_finish) {
                if (check_cursor(up_start)) {
                    selectLeft = i;
                    selectRight = 1;
                } else if (check_cursor(up_finish)) {
                    selectRight = i;
                    selectLeft = -1;
                } else {
                    selectRight = 1;
                    selectLeft = -1;
                }
            }
        }
    }

    //check to see cursor hovering 
    private boolean check_cursor(float drag_Pos) {
        return ((mouseX > drag_Pos - area_of_box) 
        && 
        (mouseX < drag_Pos + area_of_box));
    }


    public void check_for_cursor_on_rect() {
        for (int j = 0; j < tasks.size(); j++) {
            Task task = tasks.get(j);

            float up_start = map(task.getStart(), 1, 30, starting_space, width - gap);
            float up_finish = map(task.getEnd(), 1, 30, starting_space, width - gap);

            float down_begin = map(j, 0, tasks.size(), gap * 5, height - gap) - (Rect_Size / 3);
            float down_finish = down_begin + up_finish;

            if (mouseY >= down_begin && mouseY <= down_finish) {
                if (check_cursor(up_start) || check_cursor(up_finish)) {
                    cursor(HAND);
                } else {
                    cursor(ARROW);
                }
            }
        }
    }

    public void mouseDragged() {
        int position = (int) (1 + 30 * ((mouseX - (starting_space - area_of_box)) / (width - (starting_space - area_of_box))));

        if (selectLeft >= 0) {
            Task task = tasks.get(selectLeft);

            if (position > 0 && position < task.getEnd()) {
                task.setStart(position);
            }
        }else if (selectRight >= 0) {
            Task task = tasks.get(selectRight);

            if (position <= 30 && position > task.getStart()) {
                task.setEnd(position);
            }
        }
    }

    public void setup() {
        

        loadTasks();

        printTasks();
    }

    public void draw() {

        colorMode(HSB);

        background(0);

        displayTasks();

        check_for_cursor_on_rect();
    }
}